<div class="pimg2 text-center ">
        <div class="dark-wrapper">
            <div class="ptext">
                <div class="cover-container pb-5 pt-5">
                    <div class="cover-inner container  " >
                            
                    <div class="row contact-details">
                <div class="col-lg-6 text-center   reveal-left">
                <h1>Photo Ggallery</h1>
                <?php
include_once('includes/gallery.php');
?>
                     
                </div>
                <div class="col-lg-6 text-center   mb-4 reveal-right">
                <h1 >Contact details</h1>
                <img class="logo-invert mb-2" src="assets/logo-invert.svg" alt="ART Travels">
                <?php
                include_once('includes/contacts.php');
                ?>
                </div>
            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 