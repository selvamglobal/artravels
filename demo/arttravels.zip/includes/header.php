<?php date_default_timezone_set('Asia/Kolkata'); ?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <title><?php echo $title; ?> </title>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="<?php echo $description; ?>">
    <link href="https://fonts.googleapis.com/css?family=Faster+One|Roboto:100,300,400" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
 
