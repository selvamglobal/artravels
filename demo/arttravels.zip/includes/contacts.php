                   
                 <div class="bd-example">
  <address>
    <strong>Head office - Tirupur</strong><br>
    ART travels <br>
    T.S.K Nagar, 60 feet road<br>  
    Dharapuram road, Tirupur - 641 608 <br>    
  </address>
  <address>
    <strong>Branch Office - Chennai</strong><br>
    ART travels <br>
    Shop No: 41,Omni bus stand,<br>
    Koyambedu,Chennai - 600 107 <br>     
  </address>
  <h4 class="pt-2">Mobile</h4>
 +91 9344945444
  <h4 class="pt-4">Email</h4>
                    <p>info(at)arttravels(.)in</p>
</div>  

                    