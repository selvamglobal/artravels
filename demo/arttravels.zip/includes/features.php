<section id="glyphs" class="reveal-bottom">          
    
<h1 class="jumbotron-heading  text-primary">Bus amenities*</h1>
<h6> *Availablity will change based on bus modals and routes</h6>
               
        
       
        <div class="glyph text-primary"><div class="glyph-icon flaticon-mp3"></div>
        <h5>Music/MP3</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-television"></div>
        <h5>Central TV</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-camera"></div>
        <h5>CCTV camera</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-emergency-call"></div>
        <h5>Emergency contact number</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-tools"></div>
        <h5>Hammer(to break glass)</h5> 
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-fire-extinguisher"></div>
        <h5>Fire extinguisher</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-exit"></div>
        <h5>Emergency exit</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-pillow"></div>
        <h5>Pillows</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-study-light"></div>
        <h5>Study light</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-plug"></div>
        <h5> Charging point</h5>        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-video-player"></div>
        <h5>Video player</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-popcorn"></div>
        <h5>Snacks</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-blanket"></div>
        <h5>Blanket</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-wifi"></div>
        <h5>Wi-Fi</h5>
        </div>        
        
        <div class="glyph text-primary"><div class="glyph-icon flaticon-big-bottle-of-water"></div>
        <h5>Water bottle</h5>
        </div>        
        

    </section>