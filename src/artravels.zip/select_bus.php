<?php
session_start();
if(!isset($_GET['rdir'])){
	header("Location: http://www.artravels.in");
exit;	
}
$rdir = base64_decode($_GET['rdir']);
//echo  $rdir;
$rdir = explode("&",$rdir);
$where = array('',"","","","","","","","");
//board_point=Coimbatore&drop_point=Select a City&travel_date=06/10/2017&return_date=10/10/2017 
for($i=0;$i<count($rdir);$i++){
	$j= explode("=",$rdir[$i]);
	
		$where[$i]=$j[1];
	
	
}
//print_r ($where);
include_once('admin/includes/connection.php');
$pdo_connection = Connection::dbConnection();
//echo "SELECT * FROM bus WHERE board_point='".$where[0]."' AND  drop_point='".$where[1]."'";
?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <title>Select Bus: ART Travels</title>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="TBook Bus tickets easily online.">
    <link href="https://fonts.googleapis.com/css?family=Faster+One|Roboto:300,400" rel="stylesheet">
    <link rel='stylesheet' href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light ">
        <a class="navbar-brand" href="#">ART Travels</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
            aria-expanded="false" aria-label="Toggle navigation">
                      <span class="navbar-toggler-icon"></span>
                    </button>
        <div class="collapse navbar-collapse " id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Book Ticket <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Print Ticket</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Cancel Ticket</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Change Boarding Pass</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Sign In / Sign Up</a>
                </li>

            </ul>
        </div>
    </nav>
    <div class="container">
 <div class="row">
     <div class="col-md-12">
     	<h2 class="text-success">Select Bus</h2>
     </div>
     <div class="col-lg-12">
     <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                          
                           <th>Bus Name</th>                                                                             
                           
                           <th>Bus Type</th>						   
                           
                           <th>Available</th>                        
                           <th>Route</th>  
                                            
                           <th>Start Time</th>                        
                           <th>Drop Time</th> 
                           <th>Fare</th>       
                           <th width="200px;">Action</th>
                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									
									$mrows = Connection::sqlSelect($pdo_connection,"SELECT r.id, b.bus_name, b.bus_type, b.bus_reg_no, b.max_seats, b.max_seats AS available, r.fare, r.board_point, r.drop_point, r.board_time, r.drop_time  FROM bus b 
									INNER JOIN route r ON b.id = r.bus_id  
																		
									WHERE r.board_point='".$where[0]."' AND  r.drop_point='".$where[1]."' ");
									$booked_seat = 0;
									$tdate = explode("/",$where[2]);//[0]=>d [1]=>m [2]=>Y
									
									if(count($mrows)>0){
										foreach($mrows as $rows){
											$mrows1 = Connection::sqlSelect($pdo_connection,"SELECT sum(tot_seats) AS tot_seats FROM booking_details  WHERE route_id=".$rows->id." AND travel_date='".$tdate[2].'-'.$tdate[1].'-'.$tdate[0]."'  ");
											if(count($mrows1)>0){
										foreach($mrows1 as $rows1){
											$booked_seat = $rows1->tot_seats;
										}
											}
											
											?>
                                            <tr>
                         
                           <td class="center"><?php echo $rows->bus_name." - ".$rows->bus_reg_no." : ".$rows->available.' Seats'; ?></td>                         
                          
                          
                           <td class="center"><?php echo $rows->bus_type; ?></td>						   
                          
                           <td class="center"><?php echo ($rows->available-$booked_seat); ?></td>                         
                           <td class="center"><?php echo $rows->board_point.' - '.$rows->drop_point; ?></td>  
                                                  
                           <td class="center"><?php echo $rows->board_time; ?></td>                         
                           <td class="center"><?php echo $rows->drop_time; ?></td>
                           <td class="center"><i  class="fa fa-inr">&nbsp;</i><?php echo $rows->fare; ?></td>                          
                           <td class="center">	                         
                           		  <?php
								  if(($rows->available-$booked_seat)>0){
									  echo ' <a class="btn btn-sm btn-success show-busgetdetails" onClick="ViewSeats('."'".base64_encode($rows->id)."'".')"  href="#"  data-id="101" id="vs_'.base64_encode($rows->id).'"><i class="fa fa-fw fa-eye"></i> View Seats</a>';
								  }
								  else{
									   echo ' <a class="btn btn-sm btn-default show-busgetdetails" > Sold</a>';
								  }
								  ?>
                        							
                           </td>
                        </tr>
                                            <?php
										}//end for
									}//end if
									?>
                                        
                                        
                                    </tbody>
                                </table>
                            </div>
     </div>
 </div>
 </div>

    <section id="contact" class="contact features-2">
        <div class="container text-center">
            <h2 class="text-primary reveal-top">Contact Us</h2><br>
            <div class="divider"></div>
            <div class="row contact-details">
                <div class="col-lg-6 text-center reveal-left">
                    <img class="mb-5 img-fluid" src="assets/home.jpeg">
                </div>
                <div class="col-lg-6 text-left text-lg-left mb-4 reveal-right">
                    <p class="lead mt-0 mb-2">Please feel free to contact us!</p>
                    <h4 class="pt-4">Email</h4>
                    <p>info@arttravels.in</p>
                    <h4 class="pt-2">Mobile</h4>
                    <p>&#43;91 &nbsp; 1234567890 </p>
                    <p>&#43;91 &nbsp; 1234567890 </p>
                    <h4 class="pt-2">Address</h4>
                    <p>Office Address Goes here! </p>
                    <h4 class="pt-2">Follow us on Social Medai</h4>
                    <ul class="social text-left">
                        <li><a target="_blank" href="#" title="Facebook" class="fa fa-facebook text-info"></a></li>
                        <li><a target="_blank" href="#" title="Youtube" class="fa fa-youtube text-info"></a></li>
                        <li><a target="_blank" href="#" title="Google+" class="fa fa-google text-info "></a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer-3 bg-light">
            <div class="container-fluid bg-dark">
                     <div class="col text-white text-center pt-2 pb-2">Home About us Terms and Conditions Privacy Policy FAQ Why KPN? Gallery Contact us</div>
                </div>

        <div class="container-fluid">
            <div class="divider"></div>
        </div>
        <div class="container">
           
            <div class="row">
                <div class="col-md-6 text-center text-md-left mt-2  pt-2">
                    <p>Copy Rights All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-right mt-2 pt-2">
                    <p> Site Designed and developed by <a target="_blank" href="http://selvam.co.in">selvam</a> </p>
                </div>
            </div>
        </div>
    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script>
        window.sr = ScrollReveal();
        sr.reveal('.reveal-top', {
            duration: 2000, distance: '100px',
            origin: 'top'
        });
        sr.reveal('.reveal-bottom', {
            duration: 2000, distance: '100px',
            origin: 'bottom'
        });
        sr.reveal('.reveal-left', {
            duration: 2000, distance: '100px',
            origin: 'left'

        });
        sr.reveal('.reveal-right', {
            duration: 2000, distance: '100px',
            origin: 'right'
        });
    </script>

    <script>
        $(function () {
            // Smooth Scrolling
            $('a[href*="#"]:not([href="#"])').click(function () {
                if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                    var target = $(this.hash);
                    target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                    if (target.length) {
                        $('html, body').animate({
                            scrollTop: target.offset().top
                        }, 1000);
                        return false;
                    }
                }
            });
        });
		function ViewSeats(route_id){
			
			window.location = 'select_seat.php?id='+route_id;
			
		}
    </script>
</body>

</html>