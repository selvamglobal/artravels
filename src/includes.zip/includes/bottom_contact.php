<section id="contact" class="contact features-2">
        <div class="container text-center">
            <h2 class="text-primary reveal-top">Contact Us</h2><br>
            <div class="divider"></div>
            <div class="row contact-details">
                <div class="col-lg-6 text-center reveal-left">
                    <img class="mb-5 img-fluid" src="assets/home.jpeg">
                </div>
                <div class="col-lg-6 text-left text-lg-left mb-4 reveal-right">
                    <p class="lead mt-0 mb-2">Please feel free to contact us!</p>
                    <h4 class="pt-4">Email</h4>
                    <p>info@arttravels.in</p>
                    <h4 class="pt-2">Mobile</h4>
                    <p>&#43;91 &nbsp; 1234567890 </p>
                    <p>&#43;91 &nbsp; 1234567890 </p>
                    <h4 class="pt-2">Address</h4>
                    <p>Office Address Goes here! </p>
                    <h4 class="pt-2">Follow us on Social Medai</h4>
                    <ul class="social text-left">
                        <li><a target="_blank" href="#" title="Facebook" class="fa fa-facebook text-info"></a></li>
                        <li><a target="_blank" href="#" title="Youtube" class="fa fa-youtube text-info"></a></li>
                        <li><a target="_blank" href="#" title="Google+" class="fa fa-google text-info "></a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </section>