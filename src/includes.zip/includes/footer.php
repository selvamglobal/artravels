<footer class="footer-3 bg-light">
            <div class="container-fluid bg-dark">
                     <div class="col text-white text-center pt-2 pb-2">Home About us Terms and Conditions Privacy Policy FAQ Why KPN? Gallery Contact us</div>
                </div>

        <div class="container-fluid">
            <div class="divider"></div>
        </div>
        <div class="container">
           
            <div class="row">
                <div class="col-md-6 text-center text-md-left mt-2  pt-2">
                    <p>Copy Rights All rights reserved.
                    </p>
                </div>
                <div class="col-md-6 text-center text-md-right mt-2 pt-2">
                    <p> Site Designed and developed by <a target="_blank" href="http://selvam.co.in">selvam</a> </p>
                </div>
            </div>
        </div>
    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>